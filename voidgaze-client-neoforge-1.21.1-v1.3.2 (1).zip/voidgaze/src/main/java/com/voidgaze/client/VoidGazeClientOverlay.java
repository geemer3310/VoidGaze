package com.voidgaze.client;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.inventory.Slot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Client-only overlay for VoidGaze (Minecraft 1.21.1 NeoForge):
 * <ul>
 *     <li>Vertical eyes in all menus &amp; inventories (outside the inventory window), with periodic
 *     2-second blood-red eyes with black outline;</li>
 *     <li>Main menu glitch (~once a minute for ~2.2 seconds): shift, partial color inversion,
 *     random buttons losing textures, chromatic VHS scanlines;</li>
 *     <li>Custom Void-Purple &amp; Spectral-Cyan HUD sprites and running XP bar/level;</li>
 *     <li>Worn 3D armor texture corruption and first-person/hotbar item glitches during gameplay;</li>
 *     <li>Automatic non-overlap with {@code dodecahedron} when both mods are installed together.</li>
 * </ul>
 */
@EventBusSubscriber(modid = VoidGazeMod.MODID, value = Dist.CLIENT)
public final class VoidGazeClientOverlay {
    private static final Random RANDOM = new Random();

    private static final ResourceLocation CORRUPTED_HUD =
            ResourceLocation.fromNamespaceAndPath(VoidGazeMod.MODID, "textures/gui/corrupted_hud.png");
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(VoidGazeMod.MODID, "textures/gui/white.png");

    private static final ResourceLocation[] ARMOR_TEXTURES = new ResourceLocation[] {
        ResourceLocation.withDefaultNamespace("textures/models/armor/iron_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/iron_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/diamond_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/diamond_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/netherite_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/netherite_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/gold_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/gold_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/chainmail_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/chainmail_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/leather_layer_1.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/leather_layer_2.png"),
        ResourceLocation.withDefaultNamespace("textures/models/armor/turtle_layer_1.png")
    };

    // --- Vertical menu & inventory eyes state
    private static final List<MenuEyeGroup> MENU_EYE_GROUPS = new ArrayList<>();
    private static Class<?> lastMenuEyeScreenClass;

    // --- Out-of-game Main Menu 1-minute glitch & 2-second Red Eyes state (wall-clock driven)
    private static long nextMainMenuGlitchAtMs = 0L;
    private static long mainMenuGlitchUntilMs = 0L;
    private static long redEyesUntilMs = 0L;
    private static boolean menuScreenPosePushed = false;

    // --- Independent HUD glitch timer & Inventory glitch timer
    private static int clientTicks;
    private static int hudGlitchTicksLeft;
    private static int hudGlitchCooldownTicks = 120;
    private static int allHeartsMissingTicks;

    private static int invGlitchTicksLeft;
    private static int invGlitchCooldownTicks = 200;

    private static boolean armorTexturesCorrupted = false;

    private static final int[] CORRUPTED_SLOT_MODE = new int[36];
    private static final Map<AbstractWidget, int[]> WIDGET_BASE_POS = new IdentityHashMap<>();
    private static boolean containerPosePushed;

    // --- In-game Config Modal state
    private static boolean configModalOpen = false;
    private static int activeSliderIndex = -1; // 0..3 = HUD timer, 4..7 = Inventory timer

    private VoidGazeClientOverlay() {}

    /**
     * Returns {@code true} if the player currently has an active schizophrenia episode from the
     * {@code dodecahedron} mod so VoidGaze automatically pauses its glitches and never overlaps!
     */
    private static boolean isDodecahedronEpisodeActive() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            return false;
        }
        for (MobEffectInstance inst : player.getActiveEffects()) {
            ResourceLocation id = BuiltInRegistries.MOB_EFFECT.getKey(inst.getEffect().value());
            if (id != null && ("dodecahedron".equals(id.getNamespace()) || "loneliness".equals(id.getNamespace()))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isHudGlitchActive() {
        return hudGlitchTicksLeft > 0 && !isDodecahedronEpisodeActive();
    }

    private static boolean isInvGlitchActive() {
        return !configModalOpen && invGlitchTicksLeft > 0 && !isDodecahedronEpisodeActive();
    }

    private static boolean isMainMenuGlitchNow(Screen screen) {
        if (configModalOpen || !VoidGazeConfig.enableMainMenuGlitch || screen == null) {
            return false;
        }
        if (Minecraft.getInstance().player != null) {
            return false;
        }
        long now = System.currentTimeMillis();
        if (nextMainMenuGlitchAtMs == 0L) {
            nextMainMenuGlitchAtMs = now + 50000L + RANDOM.nextInt(18000);
        }
        if (now >= nextMainMenuGlitchAtMs) {
            mainMenuGlitchUntilMs = now + 2300L; // ~2.3 seconds of main menu glitch
            nextMainMenuGlitchAtMs = now + 52000L + RANDOM.nextInt(18000); // ~once a minute
            if (VoidGazeConfig.enableRedEyes) {
                redEyesUntilMs = now + 2000L; // eyes turn red with black outline for 2 seconds during main menu glitch!
            }
        }
        return now < mainMenuGlitchUntilMs;
    }

    private static boolean areMainMenuGlitchEyesRedNow(Screen screen) {
        if (!VoidGazeConfig.enableRedEyes) {
            return false;
        }
        // Only red during the Main Menu glitch (for 2 seconds), or when an individual eye is clicked (5% bleeding proc)!
        return isMainMenuGlitchNow(screen) && System.currentTimeMillis() < redEyesUntilMs;
    }

    private static boolean isRussian() {
        try {
            String code = Minecraft.getInstance().getLanguageManager().getSelected();
            return code != null && code.toLowerCase(Locale.ROOT).startsWith("ru");
        } catch (Exception ignored) {
            return true;
        }
    }

    private static int rollHudIntervalTicks() {
        VoidGazeConfig.ensureLoaded();
        int minTicks = Math.max(20, VoidGazeConfig.minIntervalSec * 20);
        int maxTicks = Math.max(minTicks, VoidGazeConfig.maxIntervalSec * 20);
        return minTicks + (maxTicks > minTicks ? RANDOM.nextInt(maxTicks - minTicks + 1) : 0);
    }

    private static int rollHudDurationTicks() {
        VoidGazeConfig.ensureLoaded();
        int minTicks = Math.max(20, VoidGazeConfig.minDurationSec * 20);
        int maxTicks = Math.max(minTicks, VoidGazeConfig.maxDurationSec * 20);
        return minTicks + (maxTicks > minTicks ? RANDOM.nextInt(maxTicks - minTicks + 1) : 0);
    }

    private static int rollInvIntervalTicks() {
        VoidGazeConfig.ensureLoaded();
        int minTicks = Math.max(20, VoidGazeConfig.invMinIntervalSec * 20);
        int maxTicks = Math.max(minTicks, VoidGazeConfig.invMaxIntervalSec * 20);
        return minTicks + (maxTicks > minTicks ? RANDOM.nextInt(maxTicks - minTicks + 1) : 0);
    }

    private static int rollInvDurationTicks() {
        VoidGazeConfig.ensureLoaded();
        int minTicks = Math.max(20, VoidGazeConfig.invMinDurationSec * 20);
        int maxTicks = Math.max(minTicks, VoidGazeConfig.invMaxDurationSec * 20);
        return minTicks + (maxTicks > minTicks ? RANDOM.nextInt(maxTicks - minTicks + 1) : 0);
    }

    public static void triggerGlitchNow() {
        hudGlitchTicksLeft = rollHudDurationTicks();
        invGlitchTicksLeft = rollInvDurationTicks();
        long now = System.currentTimeMillis();
        mainMenuGlitchUntilMs = now + 2500L;
        redEyesUntilMs = now + 2000L;
        rerollCorruptedSlots();
    }

    private static void rerollCorruptedSlots() {
        for (int i = 0; i < CORRUPTED_SLOT_MODE.length; i++) {
            if (RANDOM.nextFloat() < 0.36F) {
                CORRUPTED_SLOT_MODE[i] = RANDOM.nextBoolean() ? 1 : 2;
            } else {
                CORRUPTED_SLOT_MODE[i] = 0;
            }
        }
    }

    // --------------------------------------------------------- worn 3D armor texture corruption

    private static void updateWornArmorGlitchTextures(Minecraft mc, boolean active) {
        if (!active) {
            if (armorTexturesCorrupted) {
                armorTexturesCorrupted = false;
                for (ResourceLocation loc : ARMOR_TEXTURES) {
                    try {
                        mc.getTextureManager().register(loc, new SimpleTexture(loc));
                    } catch (Exception ignored) {
                    }
                }
            }
            return;
        }

        if (armorTexturesCorrupted && (clientTicks % 10) != 0) {
            return;
        }
        armorTexturesCorrupted = true;

        for (ResourceLocation loc : ARMOR_TEXTURES) {
            try {
                Optional<Resource> res = mc.getResourceManager().getResource(loc);
                if (res.isEmpty()) {
                    continue;
                }
                try (InputStream in = res.get().open()) {
                    NativeImage img = NativeImage.read(in);
                    int w = img.getWidth();
                    int h = img.getHeight();
                    // Apply random purple/black missing-texture checker patches & cyan/inverted strips to non-transparent armor pixels
                    int patches = 5 + RANDOM.nextInt(5);
                    for (int p = 0; p < patches; p++) {
                        int px = RANDOM.nextInt(Math.max(1, w - 6));
                        int py = RANDOM.nextInt(Math.max(1, h - 6));
                        int pw = 4 + RANDOM.nextInt(8);
                        int ph = 3 + RANDOM.nextInt(6);
                        int mode = RANDOM.nextInt(3);
                        for (int dy = 0; dy < ph && py + dy < h; dy++) {
                            for (int dx = 0; dx < pw && px + dx < w; dx++) {
                                int orig = img.getPixelRGBA(px + dx, py + dy);
                                int alpha = (orig >>> 24) & 0xFF;
                                if (alpha < 16) {
                                    continue;
                                }
                                if (mode == 0) {
                                    // 2x2 Black-and-Pink missing-texture checker (ABGR format in NativeImage: 0xFFDC00FF = R:255, G:0, B:220)
                                    boolean mag = ((dx / 2) + (dy / 2)) % 2 == 0;
                                    img.setPixelRGBA(px + dx, py + dy, mag ? 0xFFDC00FF : 0xFF000000);
                                } else if (mode == 1) {
                                    // Invert armor RGB channels
                                    int inv = (alpha << 24) | ((~orig) & 0x00FFFFFF);
                                    img.setPixelRGBA(px + dx, py + dy, inv);
                                } else {
                                    // 1x1 fine Black-and-Pink missing-texture checker
                                    img.setPixelRGBA(px + dx, py + dy, ((dx + dy) % 2 == 0) ? 0xFFDC00FF : 0xFF000000);
                                }
                            }
                        }
                    }
                    DynamicTexture dyn = new DynamicTexture(img);
                    mc.getTextureManager().register(loc, dyn);
                }
            } catch (Exception ignored) {
            }
        }
    }

    // --------------------------------------------------------- first-person held item glitch in gameplay

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (!isHudGlitchActive() || !VoidGazeConfig.enableGameplayItemGlitch) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.isPaused()) {
            return;
        }
        // Periodically glitch/jitter the held item in the player's hand during normal gameplay
        long slice = System.currentTimeMillis() / 70L;
        if ((slice % 3L) == 0L) {
            PoseStack pose = event.getPoseStack();
            int hash = ((int) slice * 73856093) ^ event.getHand().ordinal();
            float jx = ((hash & 7) - 3.5F) * 0.022F;
            float jy = (((hash >> 3) & 7) - 3.5F) * 0.018F;
            float rotZ = (((hash >> 6) & 7) - 3.5F) * 2.4F;
            pose.translate(jx, jy, 0.0F);
            pose.mulPose(Axis.ZP.rotationDegrees(rotZ));
        }
    }

    // ----------------------------------------------------------------- hotkeys (F8 opens config in-game)

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        if (event.getAction() != GLFW.GLFW_PRESS || event.getKey() != GLFW.GLFW_KEY_F8) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        VoidGazeConfig.ensureLoaded();
        if (mc.screen == null && mc.player != null) {
            mc.pauseGame(false);
            configModalOpen = true;
            activeSliderIndex = -1;
        } else if (mc.screen != null && !(mc.screen instanceof ChatScreen)) {
            configModalOpen = !configModalOpen;
            activeSliderIndex = -1;
            if (!configModalOpen) {
                VoidGazeConfig.save();
            }
        }
    }

    // ----------------------------------------------------------------- subtle camera micro-distortion

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (!isHudGlitchActive() || !VoidGazeConfig.enableScreenDistortion) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.isPaused()) {
            return;
        }
        if ((clientTicks % 18) < 3) {
            float t = clientTicks + (float) event.getPartialTick();
            event.setRoll(event.getRoll() + Mth.sin(t * 2.7F) * 0.32F);
            event.setPitch(event.getPitch() + Mth.cos(t * 2.1F) * 0.14F);
        }
    }

    // ----------------------------------------------------------------- client tick

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        VoidGazeConfig.ensureLoaded();
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null) {
            hudGlitchTicksLeft = 0;
            hudGlitchCooldownTicks = rollHudIntervalTicks();
            allHeartsMissingTicks = 0;
            invGlitchTicksLeft = 0;
            invGlitchCooldownTicks = rollInvIntervalTicks();
            updateWornArmorGlitchTextures(minecraft, false);
            WIDGET_BASE_POS.clear();
            return;
        }

        // If Dodecahedron has an active episode on the player, pause all VoidGaze glitches so nothing overlaps!
        if (isDodecahedronEpisodeActive()) {
            updateWornArmorGlitchTextures(minecraft, false);
            return;
        }

        clientTicks++;

        int maxHudAllowed = Math.max(20, VoidGazeConfig.maxIntervalSec * 20);
        if (hudGlitchCooldownTicks > maxHudAllowed) {
            hudGlitchCooldownTicks = rollHudIntervalTicks();
        }
        int maxInvAllowed = Math.max(20, VoidGazeConfig.invMaxIntervalSec * 20);
        if (invGlitchCooldownTicks > maxInvAllowed) {
            invGlitchCooldownTicks = rollInvIntervalTicks();
        }

        // 1. Independent Inventory / Menu glitch timer
        if (!configModalOpen) {
            if (invGlitchTicksLeft > 0) {
                if (minecraft.screen != null && !(minecraft.screen instanceof ChatScreen)) {
                    invGlitchTicksLeft--;
                    if (clientTicks % 22 == 1) {
                        rerollCorruptedSlots();
                    }
                }
            } else {
                if (invGlitchCooldownTicks > 0) {
                    invGlitchCooldownTicks--;
                }
                if (invGlitchCooldownTicks <= 0
                        && minecraft.screen != null
                        && !(minecraft.screen instanceof ChatScreen)) {
                    invGlitchTicksLeft = rollInvDurationTicks();
                    invGlitchCooldownTicks = rollInvIntervalTicks();
                    rerollCorruptedSlots();
                }
            }
        }

        if (minecraft.isPaused()) {
            return;
        }

        // 2. Independent HUD & Gameplay glitch timer
        if (hudGlitchTicksLeft > 0) {
            hudGlitchTicksLeft--;

            if (allHeartsMissingTicks > 0) {
                allHeartsMissingTicks--;
            } else if (clientTicks % 75 == 25 || (clientTicks % 40 == 0 && RANDOM.nextFloat() < 0.35F)) {
                allHeartsMissingTicks = 24 + RANDOM.nextInt(14);
            }

            if (clientTicks % 22 == 1) {
                rerollCorruptedSlots();
            }

            updateWornArmorGlitchTextures(minecraft, VoidGazeConfig.enableWornArmorGlitch);

            if (hudGlitchTicksLeft == 0) {
                allHeartsMissingTicks = 0;
                updateWornArmorGlitchTextures(minecraft, false);
                if (invGlitchTicksLeft <= 0) {
                    for (int i = 0; i < CORRUPTED_SLOT_MODE.length; i++) {
                        CORRUPTED_SLOT_MODE[i] = 0;
                    }
                }
            }
        } else {
            updateWornArmorGlitchTextures(minecraft, false);
            if (--hudGlitchCooldownTicks <= 0) {
                hudGlitchTicksLeft = rollHudDurationTicks();
                hudGlitchCooldownTicks = rollHudIntervalTicks();
                rerollCorruptedSlots();
            }
        }
    }

    // ----------------------------------------------------------------- HUD & light screen glitches

    @SubscribeEvent
    public static void onRenderGuiLayerPre(RenderGuiLayerEvent.Pre event) {
        if (!isHudGlitchActive()) {
            return;
        }
        String path = event.getName().getPath();
        if (path.equals("player_health") && VoidGazeConfig.enableHearts) {
            event.setCanceled(true);
        } else if (path.equals("armor_level") && VoidGazeConfig.enableArmor) {
            event.setCanceled(true);
        } else if (path.equals("food_level") && VoidGazeConfig.enableFood) {
            event.setCanceled(true);
        } else if ((path.equals("experience_bar") || path.equals("experience_level")) && VoidGazeConfig.enableXp) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRenderGuiPost(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.isPaused() || !isHudGlitchActive()) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        int realWidth = minecraft.getWindow().getGuiScaledWidth();
        int realHeight = minecraft.getWindow().getGuiScaledHeight();

        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 400.0F);
        try {
            if (VoidGazeConfig.enableScreenDistortion) {
                renderLightScreenDistortion(graphics, realWidth, realHeight);
            }
            renderCorruptedStatusBars(graphics, minecraft, realWidth, realHeight);
            if (VoidGazeConfig.enableItemGlitch || VoidGazeConfig.enableGameplayItemGlitch) {
                renderCorruptedHotbarSlots(graphics, minecraft, realWidth, realHeight);
            }
            graphics.flush();
        } finally {
            graphics.pose().popPose();
            RenderSystem.enableDepthTest();
        }
    }

    private static void renderLightScreenDistortion(GuiGraphics graphics, int w, int h) {
        long slice = System.currentTimeMillis() / 90L;

        int edgeAlpha = 18 + Math.round(10.0F * (0.5F + 0.5F * Mth.sin(clientTicks * 0.25F)));
        int edgeColor = (edgeAlpha << 24) | 0x1A062E;
        graphics.fill(0, 0, w, 4, edgeColor);
        graphics.fill(0, h - 4, w, h, edgeColor);
        graphics.fill(0, 4, 5, h - 4, edgeColor);
        graphics.fill(w - 5, 4, w, h - 4, edgeColor);

        for (int s = 0; s < 2; s++) {
            int bandZone = Math.max(12, h / 3 - 8);
            int rawY = Math.floorMod((int) (slice * (13 + s * 7) + s * 41), bandZone);
            int sy = (s == 0) ? (6 + rawY) : (h - 8 - rawY);
            int lineColor = (s == 0) ? 0x28FF00DC : 0x32000000;
            graphics.fill(0, sy, w, sy + 1, lineColor);
        }

        if ((slice % 3L) == 0L) {
            int sideW = Math.max(16, w / 6);
            for (int p = 0; p < 2; p++) {
                int hash = ((int) slice * 73856093) ^ (p * 19349663);
                boolean leftSide = (hash & 1) == 0;
                int cell = 4 + Math.floorMod(hash >> 2, 4);
                int px = leftSide
                        ? (4 + Math.floorMod(hash >> 5, Math.max(1, sideW - cell * 2)))
                        : (w - sideW + Math.floorMod(hash >> 5, Math.max(1, sideW - cell * 2 - 4)));
                int py = 8 + Math.floorMod(hash >> 11, Math.max(1, h - 48));
                if ((p == 0 && VoidGazeConfig.enableItemGlitch) || !VoidGazeConfig.enableInversion) {
                    drawCheckerCell(graphics, px, py, cell, 0x88FF00DC, 0x88000000);
                } else {
                    invertScreenRect(graphics, px, py, px + cell * 4, py + cell);
                }
            }
        }

        if (VoidGazeConfig.enableInversion && (slice % 11L) == 0L) {
            boolean topBand = ((slice / 11L) % 2L) == 0L;
            int by = topBand ? (8 + Math.floorMod((int) slice * 17, Math.max(1, h / 5)))
                    : (h - h / 5 - 12 + Math.floorMod((int) slice * 17, Math.max(1, h / 5)));
            int bx = Math.floorMod((int) slice * 31, Math.max(1, w / 2));
            int bw = Math.min(w - bx, 48 + Math.floorMod((int) slice * 23, Math.max(1, w / 3)));
            invertScreenRect(graphics, bx, by, bx + bw, by + 3);
        }
    }

    private static void renderCorruptedStatusBars(GuiGraphics graphics, Minecraft minecraft,
            int realWidth, int realHeight) {
        int left = realWidth / 2 - 91;
        int right = realWidth / 2 + 91;
        int seed = clientTicks / 2;

        // 1. Experience Bar (Black-and-Pink #FF00DC & #000000 missing-texture style!)
        if (VoidGazeConfig.enableXp) {
            int xpY = realHeight - 29;
            graphics.fill(left - 1, xpY - 1, left + 183, xpY + 6, 0xFF000000);
            graphics.fill(left, xpY, left + 182, xpY + 5, 0xFF140012);

            float wave = 0.5F + 0.5F * Mth.sin(clientTicks * 0.34F + Mth.sin(clientTicks * 0.11F) * 2.1F);
            int fillW = Mth.clamp((int) (wave * 182.0F), 8, 182);
            boolean primaryPink = ((clientTicks / 3) % 2) == 0;
            for (int segX = 0; segX < fillW; segX += 10) {
                int segW = Math.min(10, fillW - segX);
                boolean segPink = ((segX / 10) % 2 == 0) ? primaryPink : !primaryPink;
                // Missing-texture checkerboard rows inside the XP bar (top 2px and bottom 3px alternate pink/black)
                int topColor = segPink ? 0xFFFF00DC : 0xFF000000;
                int botColor = segPink ? 0xFF000000 : 0xFFFF00DC;
                graphics.fill(left + segX, xpY, left + segX + segW, xpY + 2, topColor);
                graphics.fill(left + segX, xpY + 2, left + segX + segW, xpY + 5, botColor);
            }

            int fakeLvl = Math.floorMod(seed * 73 + 17, 667);
            String lvlStr = Integer.toString(fakeLvl);
            int lw = minecraft.font.width(lvlStr);
            int lx = realWidth / 2 - lw / 2;
            int ly = realHeight - 35;
            boolean pinkText = ((clientTicks / 2) % 2 == 0);
            int lvlColor = pinkText ? 0xFFFF00DC : 0xFF100010;
            int outlineColor = pinkText ? 0xFF000000 : 0xFFFF00DC;
            graphics.drawString(minecraft.font, lvlStr, lx + 1, ly, outlineColor, false);
            graphics.drawString(minecraft.font, lvlStr, lx - 1, ly, outlineColor, false);
            graphics.drawString(minecraft.font, lvlStr, lx, ly + 1, outlineColor, false);
            graphics.drawString(minecraft.font, lvlStr, lx, ly - 1, outlineColor, false);
            graphics.drawString(minecraft.font, lvlStr, lx, ly, lvlColor, false);
        }

        // 2. Hearts / Health Bar (using VoidGaze custom purple/cyan/indigo sprite sheet)
        if (VoidGazeConfig.enableHearts) {
            int heartY = realHeight - 39;
            boolean allEmpty = allHeartsMissingTicks > 0;
            for (int i = 0; i < 10; i++) {
                int hx = left + i * 8;
                int hy = heartY + (allEmpty ? 0 : Math.floorMod((seed + i * 7) * 13, 3) - 1);
                if (allEmpty) {
                    int u = ((clientTicks / 3 + i) % 4 == 0) ? 9 : 0;
                    graphics.blit(CORRUPTED_HUD, hx, hy, u, 0, 9, 9, 64, 32);
                } else {
                    int hHash = Math.floorMod((seed * 31) ^ (i * 97), 10);
                    if (hHash == 0) {
                        continue;
                    }
                    int u = switch (hHash) {
                        case 1, 2, 3 -> 0;
                        case 4 -> 9;
                        case 5, 6 -> 27;
                        case 7 -> 36;
                        default -> 18;
                    };
                    graphics.blit(CORRUPTED_HUD, hx, hy, u, 0, 9, 9, 64, 32);
                }
            }
        }

        // 3. Armor Bar
        if (VoidGazeConfig.enableArmor) {
            int armorY = realHeight - 49;
            for (int i = 0; i < 10; i++) {
                int aHash = Math.floorMod((seed * 43) ^ (i * 61), 9);
                if (aHash <= 1) {
                    continue;
                }
                int ax = left + i * 8;
                int ay = armorY + (Math.floorMod(seed + i * 5, 3) - 1);
                int u = switch (aHash) {
                    case 2, 3 -> 0;
                    case 4, 5 -> 18;
                    default -> 9;
                };
                graphics.blit(CORRUPTED_HUD, ax, ay, u, 9, 9, 9, 64, 32);
            }
        }

        // 4. Hunger / Food Bar
        if (VoidGazeConfig.enableFood) {
            int foodY = realHeight - 39;
            for (int i = 0; i < 10; i++) {
                int fHash = Math.floorMod((seed * 53) ^ (i * 83), 9);
                if (fHash == 0) {
                    continue;
                }
                int fx = right - i * 8 - 9;
                int fy = foodY + (Math.floorMod(seed * 3 + i * 11, 3) - 1);
                int u = switch (fHash) {
                    case 1, 2, 3 -> 0;
                    case 4, 5 -> 18;
                    default -> 9;
                };
                graphics.blit(CORRUPTED_HUD, fx, fy, u, 18, 9, 9, 64, 32);
            }
        }
    }

    private static void renderCorruptedHotbarSlots(GuiGraphics graphics, Minecraft minecraft,
            int realWidth, int realHeight) {
        LocalPlayer player = minecraft.player;
        if (player == null) {
            return;
        }
        graphics.flush();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        int baseX = realWidth / 2 - 90;
        int baseY = realHeight - 19;
        long slice = System.currentTimeMillis() / 95L;
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getItem(i).isEmpty()) {
                continue;
            }
            int x = baseX + i * 20 + 3;
            int y = baseY;
            int mode = CORRUPTED_SLOT_MODE[i];
            if (mode != 0 && VoidGazeConfig.enableItemGlitch) {
                solid(graphics, x, y, x + 16, y + 16, 0xFF1A0C28);
                if (mode == 2) {
                    drawCheckerCell(graphics, x, y, 8, 0xFFFF00DC, 0xFF000000);
                }
            } else if (VoidGazeConfig.enableGameplayItemGlitch && Math.floorMod((int) slice + i * 5, 7) == 0) {
                // Partial item glitch slice / missing-texture strip on the hotbar item during normal gameplay
                int sy = y + Math.floorMod((int) slice * 3 + i * 7, 11);
                if (((i + (int) slice) & 1) == 0) {
                    invertScreenRect(graphics, x, sy, x + 16, sy + 5);
                } else {
                    drawMenuCorruptedCheckerPatch(graphics, x, sy, 16, 4, 4);
                }
            }
        }
        graphics.flush();
    }

    // --------------------------------------------------- inventory & menu glitches + vertical eyes

    @SubscribeEvent
    public static void onScreenInitPost(ScreenEvent.Init.Post event) {
        VoidGazeConfig.ensureLoaded();
        WIDGET_BASE_POS.clear();
        activeSliderIndex = -1;
        Screen screen = event.getScreen();
        if (screen instanceof ChatScreen) {
            configModalOpen = false;
        }
    }

    @SubscribeEvent
    public static void onScreenRenderPre(ScreenEvent.Render.Pre event) {
        Minecraft minecraft = Minecraft.getInstance();
        Screen screen = event.getScreen();
        boolean inGameGlitching = minecraft.player != null
                && isInvGlitchActive()
                && VoidGazeConfig.enableUiMovement
                && !(screen instanceof ChatScreen);
        boolean mainMenuGlitching = isMainMenuGlitchNow(screen);

        if (!inGameGlitching && !mainMenuGlitching) {
            restoreWidgetPositions();
            return;
        }

        float timeSec = (System.currentTimeMillis() % 120000L) / 1000.0F;
        long glitchSlice = System.currentTimeMillis() / (mainMenuGlitching ? 65L : 115L);

        if (mainMenuGlitching) {
            float shiftX = ((glitchSlice % 2L == 0L) ? 10.0F : -10.0F) + Mth.sin(timeSec * 14.0F) * 6.0F;
            float shiftY = (((glitchSlice / 2L) % 2L == 0L) ? 4.0F : -4.0F);
            event.getGuiGraphics().pose().pushPose();
            event.getGuiGraphics().pose().translate(shiftX, shiftY, 0.0F);
            menuScreenPosePushed = true;
        } else if (screen instanceof AbstractContainerScreen<?>) {
            float invWaveX = Mth.sin(timeSec * 2.9F) * 14.0F + Mth.cos(timeSec * 5.2F) * 5.0F;
            float invWaveY = Mth.cos(timeSec * 2.4F) * 8.0F + Mth.sin(timeSec * 4.5F) * 3.5F;
            if ((glitchSlice % 7L) == 0L) {
                invWaveX += ((glitchSlice % 2L == 0L) ? 18.0F : -18.0F);
            }
            event.getGuiGraphics().pose().pushPose();
            event.getGuiGraphics().pose().translate(invWaveX, invWaveY, 0.0F);
            containerPosePushed = true;
        }

        int idx = 0;
        for (GuiEventListener listener : screen.children()) {
            if (listener instanceof AbstractWidget widget) {
                int[] base = WIDGET_BASE_POS.computeIfAbsent(widget, w -> new int[] { w.getX(), w.getY() });
                float waveX = Mth.sin(timeSec * 3.1F + idx * 1.45F) * 16.0F
                        + Mth.cos(timeSec * 5.6F + idx * 2.1F) * 5.5F;
                float waveY = Mth.cos(timeSec * 2.5F + idx * 1.85F) * 8.5F
                        + Mth.sin(timeSec * 4.8F + idx * 0.95F) * 3.5F;
                if (((glitchSlice + idx * 5L) % 7L) == 0L) {
                    waveX += ((idx % 2 == 0) ? 22.0F : -22.0F);
                }
                widget.setX(base[0] + Math.round(waveX));
                widget.setY(base[1] + Math.round(waveY));
                idx++;
            }
        }
    }

    @SubscribeEvent
    public static void onScreenRenderPost(ScreenEvent.Render.Post event) {
        if (containerPosePushed) {
            event.getGuiGraphics().pose().popPose();
            containerPosePushed = false;
        }
        if (menuScreenPosePushed) {
            event.getGuiGraphics().pose().popPose();
            menuScreenPosePushed = false;
        }

        Minecraft minecraft = Minecraft.getInstance();
        Screen currentScreen = event.getScreen();
        GuiGraphics graphics = event.getGuiGraphics();
        int mouseX = event.getMouseX();
        int mouseY = event.getMouseY();

        // 1. Render vertical eyes in all menus & inventories (turns red with black outline for 2s periodically!)
        if (VoidGazeConfig.enableEyes && shouldShowMenuEyes(currentScreen)) {
            drawMainMenuEyes(graphics, currentScreen, mouseX, mouseY);
        }

        // 2a. Out-of-game Main Menu 1-minute glitch (~2.3s of shift, partial inversion, missing-texture buttons & VHS lines)
        if (isMainMenuGlitchNow(currentScreen)) {
            renderMainMenuPeriodicGlitch(graphics, currentScreen);
        }

        // 2b. In-game periodic inventory / menu glitches when the independent Inventory Timer is active
        if (minecraft.player != null && isInvGlitchActive() && !(currentScreen instanceof ChatScreen)
                && (VoidGazeConfig.enableInversion || VoidGazeConfig.enableItemGlitch)) {
            graphics.flush();
            RenderSystem.disableDepthTest();
            graphics.pose().pushPose();
            graphics.pose().translate(0.0F, 0.0F, 320.0F);
            try {
                long slice = System.currentTimeMillis() / 130L;
                float timeSec = (System.currentTimeMillis() % 120000L) / 1000.0F;
                int idx = 0;
                for (GuiEventListener listener : currentScreen.children()) {
                    if (listener instanceof AbstractWidget widget && widget.visible) {
                        int wx = widget.getX();
                        int wy = widget.getY();
                        int ww = widget.getWidth();
                        int wh = widget.getHeight();
                        int mode = Math.floorMod((int) (slice * 37L) ^ (idx * 89), 8);
                        if ((mode == 0 || mode == 1) && VoidGazeConfig.enableItemGlitch) {
                            int patchW = (mode == 0) ? ww : Math.max(16, ww / 2);
                            int patchX = (mode == 0) ? wx
                                    : wx + Math.floorMod((int) (slice * 19L + idx * 23), Math.max(1, ww - patchW));
                            drawMenuCorruptedCheckerPatch(graphics, patchX, wy, patchW, wh, 7);
                        } else if ((mode == 2 || mode == 3) && VoidGazeConfig.enableInversion) {
                            invertScreenRect(graphics, wx, wy, wx + ww, wy + wh);
                        }
                        idx++;
                    }
                }

                if (currentScreen instanceof AbstractContainerScreen<?> containerScreen) {
                    int guiLeft = containerScreen.getGuiLeft();
                    int guiTop = containerScreen.getGuiTop();
                    int guiW = containerScreen.getXSize();
                    int guiH = containerScreen.getYSize();

                    for (int b = 0; b < 4; b++) {
                        int driftX = Math.round(Mth.sin(timeSec * 3.2F + b * 1.6F) * 14.0F);
                        int driftY = Math.round(Mth.cos(timeSec * 2.6F + b * 1.9F) * 9.0F);
                        int bx = guiLeft + 8 + (b % 2) * (guiW / 2 - 8) + driftX;
                        int by = guiTop + 14 + (b / 2) * (guiH / 2 - 12) + driftY;
                        int bw = Math.max(28, guiW / 2 - 14);
                        int bh = 22;
                        int bMode = Math.floorMod((int) (slice * 29L) ^ (b * 67), 5);
                        if ((bMode == 0 || bMode == 1) && VoidGazeConfig.enableInversion) {
                            invertScreenRect(graphics, bx, by, bx + bw, by + bh);
                        } else if (bMode == 2 && VoidGazeConfig.enableItemGlitch) {
                            drawMenuCorruptedCheckerPatch(graphics, bx, by, bw, bh, 7);
                        }
                    }

                    for (Slot slot : containerScreen.getMenu().slots) {
                        if (!slot.isActive()) {
                            continue;
                        }
                        int sHash = Math.floorMod((int) (slice * 41L) ^ (slot.index * 73), 11);
                        int sx = guiLeft + slot.x + Math.round(Mth.sin(timeSec * 3.4F + slot.index * 0.7F) * 4.0F);
                        int sy = guiTop + slot.y + Math.round(Mth.cos(timeSec * 2.9F + slot.index * 0.9F) * 3.0F);
                        if ((sHash == 0 || sHash == 1) && VoidGazeConfig.enableItemGlitch) {
                            drawCheckerCell(graphics, sx, sy, 8, 0xFFFF00DC, 0xFF000000);
                        } else if ((sHash == 2 || sHash == 3) && VoidGazeConfig.enableInversion) {
                            invertScreenRect(graphics, sx, sy, sx + 16, sy + 16);
                        } else if (VoidGazeConfig.enableItemGlitch && !slot.getItem().isEmpty()
                                && CORRUPTED_SLOT_MODE[Math.floorMod(slot.index, CORRUPTED_SLOT_MODE.length)] != 0) {
                            solid(graphics, guiLeft + slot.x, guiTop + slot.y,
                                    guiLeft + slot.x + 16, guiTop + slot.y + 16, 0xFF8B8B8B);
                        }
                    }
                }

                int sw = Math.max(64, currentScreen.width);
                int sh = Math.max(64, currentScreen.height);
                if (VoidGazeConfig.enableItemGlitch) {
                    int patchCount = 4 + Math.floorMod((int) slice * 17, 4);
                    for (int p = 0; p < patchCount; p++) {
                        int hash = ((int) slice * 73856093) ^ (p * 19349663);
                        int cell = 7 + Math.floorMod(hash >> 3, 9);
                        int px = Math.floorMod(hash >> 7, Math.max(1, sw - cell * 2));
                        int py = Math.floorMod(hash >> 13, Math.max(1, sh - cell * 2));
                        drawCheckerCell(graphics, px, py, cell, 0xCCFF00DC, 0xCC000000);
                    }
                }

                if (VoidGazeConfig.enableInversion) {
                    int invMode = Math.floorMod((int) (System.currentTimeMillis() / 160L), 9);
                    if (invMode == 0) {
                        invertScreenRect(graphics, 0, 0, sw, sh);
                    } else if (invMode == 3 || invMode == 6) {
                        int bandY = Math.floorMod((int) (slice * 53L), Math.max(1, sh - 60));
                        invertScreenRect(graphics, 0, bandY, sw, Math.min(sh, bandY + 56));
                    }
                }
                graphics.flush();
            } finally {
                graphics.pose().popPose();
                RenderSystem.enableDepthTest();
            }
        }

        // Restore widget coordinates right after rendering so clicks always work normally on any server!
        restoreWidgetPositions();

        // 3. Draw the "[⚙ VoidGaze]" button in menus, OR the full Config Modal
        if (shouldShowConfigButton(currentScreen) || configModalOpen) {
            drawConfigUi(graphics, minecraft.font, currentScreen, mouseX, mouseY);
        }
    }

    /**
     * Renders the ~2.3-second Main Menu glitch burst (~once per minute):
     * random buttons lose their texture (purple/black checker), partial color inversions flash,
     * and VHS cyan/magenta chromatic aberration scanlines tear across the screen.
     */
    private static void renderMainMenuPeriodicGlitch(GuiGraphics graphics, Screen menuScreen) {
        graphics.flush();
        RenderSystem.disableDepthTest();
        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 340.0F);
        try {
            long slice = System.currentTimeMillis() / 85L;
            int sw = Math.max(64, menuScreen.width);
            int sh = Math.max(64, menuScreen.height);

            // 1. Random buttons lose their texture (missing-texture checkerboard) or invert
            int idx = 0;
            for (GuiEventListener listener : menuScreen.children()) {
                if (listener instanceof AbstractWidget widget && widget.visible) {
                    int wx = widget.getX();
                    int wy = widget.getY();
                    int ww = widget.getWidth();
                    int wh = widget.getHeight();
                    int mode = Math.floorMod((int) (slice * 31L) ^ (idx * 73), 5);
                    if (mode == 0 || mode == 1) {
                        drawMenuCorruptedCheckerPatch(graphics, wx, wy, ww, wh, 6);
                    } else if (mode == 2) {
                        invertScreenRect(graphics, wx, wy, wx + ww, wy + wh);
                    }
                    idx++;
                }
            }

            // 2. Partial color inversion bands across the menu
            for (int b = 0; b < 2; b++) {
                int bandH = 18 + Math.floorMod((int) slice * 13 + b * 29, 36);
                int bandY = Math.floorMod((int) (slice * 47L + b * 113L), Math.max(1, sh - bandH));
                int bandX = (b == 0) ? 0 : Math.floorMod((int) slice * 23, sw / 3);
                int bandW = (b == 0) ? sw : Math.min(sw - bandX, sw * 2 / 3);
                invertScreenRect(graphics, bandX, bandY, bandX + bandW, bandY + bandH);
            }

            // 3. VHS chromatic aberration tear lines & missing-texture squares
            for (int l = 0; l < 4; l++) {
                int ly = Math.floorMod((int) (slice * 37L + l * 61L), sh);
                int col = (l % 2 == 0) ? 0x8828F0FF : 0x88FF18DC;
                solid(graphics, 0, ly, sw, ly + 2, col);
            }
            for (int p = 0; p < 4; p++) {
                int hash = ((int) slice * 73856093) ^ (p * 19349663);
                int cell = 6 + Math.floorMod(hash >> 3, 8);
                int px = Math.floorMod(hash >> 7, Math.max(1, sw - cell * 2));
                int py = Math.floorMod(hash >> 13, Math.max(1, sh - cell * 2));
                drawCheckerCell(graphics, px, py, cell, 0xCCFF00DC, 0xCC000000);
            }
            graphics.flush();
        } finally {
            graphics.pose().popPose();
            RenderSystem.enableDepthTest();
        }
    }

    // --------------------------------------------------- in-game Config UI rendering & interaction

    private static boolean shouldShowConfigButton(Screen screen) {
        if (screen == null || screen instanceof ChatScreen || screen instanceof AbstractContainerScreen<?>) {
            return false;
        }
        return true;
    }

    private static int[] getOpenButtonBounds(Screen screen) {
        int w = 138;
        int h = 20;
        int x = Math.max(6, screen.width - w - 8);
        int y = 8;
        return new int[] { x, y, w, h };
    }

    private static int[] getModalBounds(Screen screen) {
        int mw = Math.min(380, Math.max(296, screen.width - 14));
        int mh = Math.min(282, Math.max(240, screen.height - 8));
        int mx = (screen.width - mw) / 2;
        int my = (screen.height - mh) / 2;
        return new int[] { mx, my, mw, mh };
    }

    private static void drawConfigUi(GuiGraphics graphics, Font font, Screen screen, int mouseX, int mouseY) {
        boolean ru = isRussian();
        graphics.flush();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 500.0F);
        try {
            if (!configModalOpen) {
                int[] btn = getOpenButtonBounds(screen);
                boolean hover = mouseX >= btn[0] && mouseX < btn[0] + btn[2]
                        && mouseY >= btn[1] && mouseY < btn[1] + btn[3];
                drawStyledButton(graphics, font, btn[0], btn[1], btn[2], btn[3],
                        ru ? "⚙ Настройки VoidGaze" : "⚙ VoidGaze Settings", hover, 0xFFE6E0F8);
                graphics.flush();
                return;
            }

            solid(graphics, 0, 0, screen.width, screen.height, 0xB805020A);

            int[] mb = getModalBounds(screen);
            int mx = mb[0];
            int my = mb[1];
            int mw = mb[2];
            int mh = mb[3];

            solid(graphics, mx - 2, my - 2, mx + mw + 2, my + mh + 2, 0xFF9A68D8);
            solid(graphics, mx - 1, my - 1, mx + mw + 1, my + mh + 1, 0xFF1E122C);
            solid(graphics, mx, my, mx + mw, my + mh, 0xF20D0814);
            solid(graphics, mx, my, mx + mw, my + 16, 0xFF1B1029);

            String title = ru ? "Настройки VoidGaze (F8)" : "VoidGaze Settings (F8)";
            graphics.drawString(font, title, mx + (mw - font.width(title)) / 2, my + 4, 0xFFF0E8FF, true);

            int pad = 7;
            int colW = (mw - pad * 3) / 2;
            int leftX = mx + pad;
            int rightX = mx + pad * 2 + colW;
            int sH = 14;

            int[] sYs = new int[] { my + 19, my + 35, my + 52, my + 68 };
            String[] sLabels = new String[] {
                (ru ? "Мин. пауза HUD: " : "HUD Min Wait: ") + VoidGazeConfig.minIntervalSec + (ru ? " с" : "s"),
                (ru ? "Макс. пауза HUD: " : "HUD Max Wait: ") + VoidGazeConfig.maxIntervalSec + (ru ? " с" : "s"),
                (ru ? "Мин. длит. HUD: " : "HUD Min Dur: ") + VoidGazeConfig.minDurationSec + (ru ? " с" : "s"),
                (ru ? "Макс. длит. HUD: " : "HUD Max Dur: ") + VoidGazeConfig.maxDurationSec + (ru ? " с" : "s"),
                (ru ? "Мин. пауза инв.: " : "Inv Min Wait: ") + VoidGazeConfig.invMinIntervalSec + (ru ? " с" : "s"),
                (ru ? "Макс. пауза инв.: " : "Inv Max Wait: ") + VoidGazeConfig.invMaxIntervalSec + (ru ? " с" : "s"),
                (ru ? "Мин. длит. инв.: " : "Inv Min Dur: ") + VoidGazeConfig.invMinDurationSec + (ru ? " с" : "s"),
                (ru ? "Макс. длит. инв.: " : "Inv Max Dur: ") + VoidGazeConfig.invMaxDurationSec + (ru ? " с" : "s")
            };
            float[] sNorms = new float[] {
                (VoidGazeConfig.minIntervalSec - 1) / 299.0F,
                (VoidGazeConfig.maxIntervalSec - 1) / 299.0F,
                (VoidGazeConfig.minDurationSec - 1) / 119.0F,
                (VoidGazeConfig.maxDurationSec - 1) / 119.0F,
                (VoidGazeConfig.invMinIntervalSec - 1) / 299.0F,
                (VoidGazeConfig.invMaxIntervalSec - 1) / 299.0F,
                (VoidGazeConfig.invMinDurationSec - 1) / 119.0F,
                (VoidGazeConfig.invMaxDurationSec - 1) / 119.0F
            };

            for (int s = 0; s < 8; s++) {
                int sx = (s % 2 == 0) ? leftX : rightX;
                int sy = sYs[s / 2];
                drawSlider(graphics, font, sx, sy, colW, sH, sLabels[s], sNorms[s],
                        isHovered(mouseX, mouseY, sx, sy, colW, sH) || activeSliderIndex == s);
            }

            // --- 13 Individual Feature Toggles
            String[] labels = ru ? new String[] {
                "Сердца", "Опыт (чёрно-розовый)",
                "Броня (шкала)", "Еда (голод)",
                "Инверсия цветов", "Движение UI",
                "Глюк слотов", "Глаза в меню",
                "Красные глаза", "Глюк гл. меню (1м)",
                "Глюк одетой брони", "Глюк предметов в руке",
                "Легкое искажение экрана"
            } : new String[] {
                "Hearts", "XP (Black/Pink)",
                "Armor Bar", "Food / Hunger",
                "Color Inversion", "UI Movement",
                "Slot Glitch", "Menu Eyes",
                "Red Eyes", "Main Menu Glitch",
                "Worn Armor Glitch", "Held Item Glitch",
                "Light Screen Glitch"
            };
            boolean[] states = new boolean[] {
                VoidGazeConfig.enableHearts, VoidGazeConfig.enableXp,
                VoidGazeConfig.enableArmor, VoidGazeConfig.enableFood,
                VoidGazeConfig.enableInversion, VoidGazeConfig.enableUiMovement,
                VoidGazeConfig.enableItemGlitch, VoidGazeConfig.enableEyes,
                VoidGazeConfig.enableRedEyes, VoidGazeConfig.enableMainMenuGlitch,
                VoidGazeConfig.enableWornArmorGlitch, VoidGazeConfig.enableGameplayItemGlitch,
                VoidGazeConfig.enableScreenDistortion
            };

            int tStartY = my + 86;
            int tStepY = 17;
            int tH = 15;
            for (int i = 0; i < 13; i++) {
                int bx = (i == 12) ? leftX : ((i % 2 == 0) ? leftX : rightX);
                int bw = (i == 12) ? (mw - pad * 2) : colW;
                int by = tStartY + (i / 2) * tStepY;
                boolean on = states[i];
                String stateTxt = on ? (ru ? "ВКЛ" : "ON") : (ru ? "ВЫКЛ" : "OFF");
                String fullTxt = labels[i] + ": " + stateTxt;
                int textColor = on ? 0xFF70FF88 : 0xFFFF6878;
                boolean hov = isHovered(mouseX, mouseY, bx, by, bw, tH);
                drawStyledButton(graphics, font, bx, by, bw, tH, fullTxt, hov, textColor);
            }

            // --- Bottom row: Test Now / Reset / Done
            int botY = my + mh - 20;
            int botW = (mw - pad * 4) / 3;
            int b1X = mx + pad;
            int b2X = b1X + botW + pad;
            int b3X = b2X + botW + pad;

            drawStyledButton(graphics, font, b1X, botY, botW, 16,
                    ru ? "▶ Тест сейчас" : "▶ Test Now",
                    isHovered(mouseX, mouseY, b1X, botY, botW, 16), 0xFFFFD866);
            drawStyledButton(graphics, font, b2X, botY, botW, 16,
                    ru ? "↺ Сброс" : "↺ Defaults",
                    isHovered(mouseX, mouseY, b2X, botY, botW, 16), 0xFFD0C8E8);
            drawStyledButton(graphics, font, b3X, botY, botW, 16,
                    ru ? "✕ Готово" : "✕ Done",
                    isHovered(mouseX, mouseY, b3X, botY, botW, 16), 0xFFFFFFFF);

            graphics.flush();
        } finally {
            graphics.pose().popPose();
            RenderSystem.enableDepthTest();
        }
    }

    private static boolean isHovered(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void drawStyledButton(GuiGraphics graphics, Font font,
            int x, int y, int w, int h, String label, boolean hovered, int textColor) {
        int border = hovered ? 0xFFD8B0FF : 0xFF5E4282;
        int bg = hovered ? 0xFF2D1C44 : 0xFF181024;
        solid(graphics, x, y, x + w, y + h, border);
        solid(graphics, x + 1, y + 1, x + w - 1, y + h - 1, bg);
        int tx = x + (w - font.width(label)) / 2;
        int ty = y + (h - 8) / 2;
        graphics.drawString(font, label, tx, ty, textColor, true);
    }

    private static void drawSlider(GuiGraphics graphics, Font font,
            int x, int y, int w, int h, String label, float normVal, boolean hovered) {
        normVal = Mth.clamp(normVal, 0.0F, 1.0F);
        int border = hovered ? 0xFFE2B8FF : 0xFF5E4282;
        solid(graphics, x, y, x + w, y + h, border);
        solid(graphics, x + 1, y + 1, x + w - 1, y + h - 1, 0xFF120B1C);

        int fillW = Math.round((w - 2) * normVal);
        if (fillW > 0) {
            solid(graphics, x + 1, y + 1, x + 1 + fillW, y + h - 1, 0xFF582E8A);
        }
        int knobX = Mth.clamp(x + 1 + fillW - 2, x + 1, x + w - 5);
        solid(graphics, knobX, y + 1, knobX + 4, y + h - 1, 0xFFD8B4FF);

        int tx = x + (w - font.width(label)) / 2;
        int ty = y + (h - 8) / 2;
        graphics.drawString(font, label, tx, ty, 0xFFF6F0FF, true);
    }

    private static void updateSliderFromMouse(int sliderIdx, double mouseX, int sliderX, int sliderW) {
        float ratio = Mth.clamp((float) ((mouseX - (sliderX + 2)) / (double) Math.max(1, sliderW - 4)), 0.0F, 1.0F);
        switch (sliderIdx) {
            case 0 -> {
                VoidGazeConfig.minIntervalSec = 1 + Math.round(ratio * 299.0F);
                if (VoidGazeConfig.maxIntervalSec < VoidGazeConfig.minIntervalSec) {
                    VoidGazeConfig.maxIntervalSec = VoidGazeConfig.minIntervalSec;
                }
            }
            case 1 -> {
                VoidGazeConfig.maxIntervalSec = 1 + Math.round(ratio * 299.0F);
                if (VoidGazeConfig.minIntervalSec > VoidGazeConfig.maxIntervalSec) {
                    VoidGazeConfig.minIntervalSec = VoidGazeConfig.maxIntervalSec;
                }
            }
            case 2 -> {
                VoidGazeConfig.minDurationSec = 1 + Math.round(ratio * 119.0F);
                if (VoidGazeConfig.maxDurationSec < VoidGazeConfig.minDurationSec) {
                    VoidGazeConfig.maxDurationSec = VoidGazeConfig.minDurationSec;
                }
            }
            case 3 -> {
                VoidGazeConfig.maxDurationSec = 1 + Math.round(ratio * 119.0F);
                if (VoidGazeConfig.minDurationSec > VoidGazeConfig.maxDurationSec) {
                    VoidGazeConfig.minDurationSec = VoidGazeConfig.maxDurationSec;
                }
            }
            case 4 -> {
                VoidGazeConfig.invMinIntervalSec = 1 + Math.round(ratio * 299.0F);
                if (VoidGazeConfig.invMaxIntervalSec < VoidGazeConfig.invMinIntervalSec) {
                    VoidGazeConfig.invMaxIntervalSec = VoidGazeConfig.invMinIntervalSec;
                }
            }
            case 5 -> {
                VoidGazeConfig.invMaxIntervalSec = 1 + Math.round(ratio * 299.0F);
                if (VoidGazeConfig.invMinIntervalSec > VoidGazeConfig.invMaxIntervalSec) {
                    VoidGazeConfig.invMinIntervalSec = VoidGazeConfig.invMaxIntervalSec;
                }
            }
            case 6 -> {
                VoidGazeConfig.invMinDurationSec = 1 + Math.round(ratio * 119.0F);
                if (VoidGazeConfig.invMaxDurationSec < VoidGazeConfig.invMinDurationSec) {
                    VoidGazeConfig.invMaxDurationSec = VoidGazeConfig.invMinDurationSec;
                }
            }
            case 7 -> {
                VoidGazeConfig.invMaxDurationSec = 1 + Math.round(ratio * 119.0F);
                if (VoidGazeConfig.invMinDurationSec > VoidGazeConfig.invMaxDurationSec) {
                    VoidGazeConfig.invMinDurationSec = VoidGazeConfig.invMaxDurationSec;
                }
            }
            default -> {}
        }
        VoidGazeConfig.save();
    }

    @SubscribeEvent
    public static void onScreenMouseClickPre(ScreenEvent.MouseButtonPressed.Pre event) {
        Screen screen = event.getScreen();
        int mx = (int) event.getMouseX();
        int my = (int) event.getMouseY();

        if (!configModalOpen) {
            if (event.getButton() == 0 && shouldShowConfigButton(screen)) {
                int[] btn = getOpenButtonBounds(screen);
                if (isHovered(mx, my, btn[0], btn[1], btn[2], btn[3])) {
                    configModalOpen = true;
                    activeSliderIndex = -1;
                    event.setCanceled(true);
                    return;
                }
            }
            if (event.getButton() == 0 && VoidGazeConfig.enableEyes && shouldShowMenuEyes(screen)) {
                tryClickMenuEye(screen, event.getMouseX(), event.getMouseY());
            }
            return;
        }

        event.setCanceled(true);
        if (event.getButton() != 0) {
            return;
        }

        int[] mb = getModalBounds(screen);
        int modalX = mb[0];
        int modalY = mb[1];
        int modalW = mb[2];
        int modalH = mb[3];

        if (!isHovered(mx, my, modalX, modalY, modalW, modalH)) {
            configModalOpen = false;
            activeSliderIndex = -1;
            VoidGazeConfig.save();
            return;
        }

        int pad = 7;
        int colW = (modalW - pad * 3) / 2;
        int leftX = modalX + pad;
        int rightX = modalX + pad * 2 + colW;
        int sH = 14;
        int[] sYs = new int[] { modalY + 19, modalY + 35, modalY + 52, modalY + 68 };

        for (int s = 0; s < 8; s++) {
            int sx = (s % 2 == 0) ? leftX : rightX;
            int sy = sYs[s / 2];
            if (isHovered(mx, my, sx, sy, colW, sH)) {
                activeSliderIndex = s;
                updateSliderFromMouse(s, event.getMouseX(), sx, colW);
                return;
            }
        }

        int tStartY = modalY + 86;
        int tStepY = 17;
        int tH = 15;
        for (int i = 0; i < 13; i++) {
            int bx = (i == 12) ? leftX : ((i % 2 == 0) ? leftX : rightX);
            int bw = (i == 12) ? (modalW - pad * 2) : colW;
            int by = tStartY + (i / 2) * tStepY;
            if (isHovered(mx, my, bx, by, bw, tH)) {
                switch (i) {
                    case 0 -> VoidGazeConfig.enableHearts = !VoidGazeConfig.enableHearts;
                    case 1 -> VoidGazeConfig.enableXp = !VoidGazeConfig.enableXp;
                    case 2 -> VoidGazeConfig.enableArmor = !VoidGazeConfig.enableArmor;
                    case 3 -> VoidGazeConfig.enableFood = !VoidGazeConfig.enableFood;
                    case 4 -> VoidGazeConfig.enableInversion = !VoidGazeConfig.enableInversion;
                    case 5 -> VoidGazeConfig.enableUiMovement = !VoidGazeConfig.enableUiMovement;
                    case 6 -> VoidGazeConfig.enableItemGlitch = !VoidGazeConfig.enableItemGlitch;
                    case 7 -> VoidGazeConfig.enableEyes = !VoidGazeConfig.enableEyes;
                    case 8 -> VoidGazeConfig.enableRedEyes = !VoidGazeConfig.enableRedEyes;
                    case 9 -> VoidGazeConfig.enableMainMenuGlitch = !VoidGazeConfig.enableMainMenuGlitch;
                    case 10 -> VoidGazeConfig.enableWornArmorGlitch = !VoidGazeConfig.enableWornArmorGlitch;
                    case 11 -> VoidGazeConfig.enableGameplayItemGlitch = !VoidGazeConfig.enableGameplayItemGlitch;
                    case 12 -> VoidGazeConfig.enableScreenDistortion = !VoidGazeConfig.enableScreenDistortion;
                    default -> {}
                }
                VoidGazeConfig.save();
                return;
            }
        }

        int botY = modalY + modalH - 20;
        int botW = (modalW - pad * 4) / 3;
        int b1X = modalX + pad;
        int b2X = b1X + botW + pad;
        int b3X = b2X + botW + pad;

        if (isHovered(mx, my, b1X, botY, botW, 16)) {
            triggerGlitchNow();
            configModalOpen = false;
        } else if (isHovered(mx, my, b2X, botY, botW, 16)) {
            VoidGazeConfig.resetDefaults();
        } else if (isHovered(mx, my, b3X, botY, botW, 16)) {
            VoidGazeConfig.save();
            configModalOpen = false;
        }
    }

    @SubscribeEvent
    public static void onScreenMouseDragPre(ScreenEvent.MouseDragged.Pre event) {
        if (!configModalOpen) {
            return;
        }
        event.setCanceled(true);
        if (activeSliderIndex < 0) {
            return;
        }
        Screen screen = event.getScreen();
        int[] mb = getModalBounds(screen);
        int modalX = mb[0];
        int modalW = mb[2];
        int pad = 7;
        int colW = (modalW - pad * 3) / 2;
        int leftX = modalX + pad;
        int rightX = modalX + pad * 2 + colW;
        int sx = (activeSliderIndex % 2 == 0) ? leftX : rightX;
        updateSliderFromMouse(activeSliderIndex, event.getMouseX(), sx, colW);
    }

    @SubscribeEvent
    public static void onScreenMouseReleasePre(ScreenEvent.MouseButtonReleased.Pre event) {
        if (!configModalOpen) {
            return;
        }
        activeSliderIndex = -1;
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onScreenKeyPressPre(ScreenEvent.KeyPressed.Pre event) {
        if (!configModalOpen) {
            return;
        }
        if (event.getKeyCode() == GLFW.GLFW_KEY_ESCAPE || event.getKeyCode() == GLFW.GLFW_KEY_F8) {
            configModalOpen = false;
            activeSliderIndex = -1;
            VoidGazeConfig.save();
            event.setCanceled(true);
        }
    }

    // --------------------------------------------------- helpers

    private static void restoreWidgetPositions() {
        if (!WIDGET_BASE_POS.isEmpty()) {
            for (Map.Entry<AbstractWidget, int[]> entry : WIDGET_BASE_POS.entrySet()) {
                AbstractWidget w = entry.getKey();
                int[] base = entry.getValue();
                if (w != null && base != null) {
                    w.setX(base[0]);
                    w.setY(base[1]);
                }
            }
        }
    }

    private static void invertScreenRect(GuiGraphics graphics, int x1, int y1, int x2, int y2) {
        if (x2 <= x1 || y2 <= y1) {
            return;
        }
        graphics.flush();
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                GlStateManager.SourceFactor.ONE_MINUS_DST_COLOR,
                GlStateManager.DestFactor.ZERO,
                GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        graphics.blit(WHITE, x1, y1, x2 - x1, y2 - y1, 0, 0, 1, 1, 1, 1);
        graphics.flush();
        RenderSystem.defaultBlendFunc();
    }

    private static void solid(GuiGraphics graphics, int x1, int y1, int x2, int y2, int argb) {
        if (x2 <= x1 || y2 <= y1) {
            return;
        }
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.setColor(((argb >> 16) & 0xFF) / 255.0F, ((argb >> 8) & 0xFF) / 255.0F,
                (argb & 0xFF) / 255.0F, ((argb >>> 24) & 0xFF) / 255.0F);
        graphics.blit(WHITE, x1, y1, x2 - x1, y2 - y1, 0, 0, 1, 1, 1, 1);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private static void drawMenuCorruptedCheckerPatch(GuiGraphics graphics, int x, int y, int w, int h, int cell) {
        graphics.flush();
        RenderSystem.disableDepthTest();
        for (int cy = y; cy < y + h; cy += cell) {
            int ch = Math.min(cell, y + h - cy);
            for (int cx = x; cx < x + w; cx += cell) {
                int cw = Math.min(cell, x + w - cx);
                boolean mag = (((cx - x) / cell) + ((cy - y) / cell)) % 2 == 0;
                solid(graphics, cx, cy, cx + cw, cy + ch, mag ? 0xDDFF00DC : 0xDD000000);
            }
        }
    }

    private static void drawCheckerCell(GuiGraphics graphics, int x, int y, int half, int c1, int c2) {
        graphics.flush();
        RenderSystem.disableDepthTest();
        solid(graphics, x, y, x + half, y + half, c1);
        solid(graphics, x + half, y, x + half * 2, y + half, c2);
        solid(graphics, x, y + half, x + half, y + half * 2, c2);
        solid(graphics, x + half, y + half, x + half * 2, y + half * 2, c1);
    }

    // --------------------------------------------------- vertical eyes in menus & inventories

    private static boolean shouldShowMenuEyes(Screen screen) {
        if (screen == null) {
            return false;
        }
        if (screen instanceof ChatScreen) {
            return false;
        }
        return true;
    }

    private static int[] getInventoryForbiddenRect(Screen screen) {
        if (!(screen instanceof AbstractContainerScreen<?> containerScreen)) {
            return null;
        }
        int guiLeft = containerScreen.getGuiLeft();
        int guiTop = containerScreen.getGuiTop();
        int guiRight = guiLeft + containerScreen.getXSize();
        int guiBottom = guiTop + containerScreen.getYSize();

        int centeredLeft = (screen.width - containerScreen.getXSize()) / 2;
        if (guiLeft > centeredLeft + 16) {
            guiLeft = Math.min(guiLeft, containerScreen.getGuiLeft() - 154);
        }

        int padX = 10;
        int padY = 28;
        return new int[] {
            guiLeft - padX,
            guiTop - padY,
            guiRight + padX,
            guiBottom + padY
        };
    }

    private static boolean overlapsRect(int cx, int cy, int halfW, int halfH, int[] rect) {
        if (rect == null) {
            return false;
        }
        return (cx + halfW + 3 >= rect[0])
                && (cx - halfW - 3 <= rect[2])
                && (cy + halfH + 3 >= rect[1])
                && (cy - halfH - 3 <= rect[3]);
    }

    private static void tryClickMenuEye(Screen screen, double mouseX, double mouseY) {
        if (screen == null || MENU_EYE_GROUPS.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        for (MenuEyeGroup eye : MENU_EYE_GROUPS) {
            long elapsed = now - eye.cycleStartMs;
            if (elapsed <= 0L || elapsed >= eye.activeDurationMs || eye.snappingClosed || eye.bleedingRed) {
                continue;
            }
            int ex = Mth.clamp(Math.round(eye.normX * screen.width),
                    eye.halfW + 6, Math.max(eye.halfW + 8, screen.width - eye.halfW - 6));
            int ey = Mth.clamp(Math.round(eye.normY * screen.height),
                    eye.halfH + 6, Math.max(eye.halfH + 8, screen.height - eye.halfH - 6));
            if (mouseX >= ex - eye.halfW - 4 && mouseX <= ex + eye.halfW + 4
                    && mouseY >= ey - eye.halfH - 4 && mouseY <= ey + eye.halfH + 4) {
                if (VoidGazeConfig.enableRedEyes && RANDOM.nextFloat() < 0.05F) {
                    // 5% chance: eye turns crimson-red and bleeds for 1.25s, then snaps shut!
                    eye.bleedingRed = true;
                    eye.bleedStartMs = now;
                    eye.activeDurationMs = Math.max(eye.activeDurationMs, (now - eye.cycleStartMs) + 1250L);
                } else {
                    // 95% chance: eye sharply snaps shut in 165ms and disappears!
                    eye.snappingClosed = true;
                    eye.snapStartMs = now;
                }
                break;
            }
        }
    }

    private static void drawMainMenuEyes(GuiGraphics graphics, Screen screen, int mouseX, int mouseY) {
        if (screen == null || screen.width < 80 || screen.height < 60) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean isTitle = screen instanceof TitleScreen;
        int targetEyes = isTitle ? 6 : 5;
        int[] invForbid = getInventoryForbiddenRect(screen);
        boolean menuGlitchRedEyes = areMainMenuGlitchEyesRedNow(screen);

        if (lastMenuEyeScreenClass != screen.getClass()) {
            lastMenuEyeScreenClass = screen.getClass();
            MENU_EYE_GROUPS.clear();
        }
        while (MENU_EYE_GROUPS.size() < targetEyes) {
            MenuEyeGroup eye = new MenuEyeGroup();
            eye.respawn(screen, MENU_EYE_GROUPS, now - RANDOM.nextInt(3400));
            MENU_EYE_GROUPS.add(eye);
        }

        graphics.flush();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 180.0F);
        try {
            for (int i = 0; i < targetEyes && i < MENU_EYE_GROUPS.size(); i++) {
                MenuEyeGroup eye = MENU_EYE_GROUPS.get(i);
                if (now >= eye.cycleStartMs + eye.activeDurationMs + eye.pauseDurationMs) {
                    eye.respawn(screen, MENU_EYE_GROUPS, now);
                }
                long elapsed = now - eye.cycleStartMs;
                if (elapsed <= 0L || elapsed >= eye.activeDurationMs) {
                    continue;
                }

                float openCurve;
                if (eye.snappingClosed) {
                    long snapElapsed = now - eye.snapStartMs;
                    if (snapElapsed >= 165L) {
                        eye.snappingClosed = false;
                        eye.cycleStartMs = now - eye.activeDurationMs;
                        eye.pauseDurationMs = 900L + RANDOM.nextInt(1500);
                        continue;
                    }
                    float snapT = Mth.clamp(snapElapsed / 165.0F, 0.0F, 1.0F);
                    openCurve = (1.0F - snapT) * (1.0F - snapT);
                } else if (eye.bleedingRed) {
                    long bleedElapsed = now - eye.bleedStartMs;
                    if (bleedElapsed >= 1250L) {
                        eye.bleedingRed = false;
                        eye.cycleStartMs = now - eye.activeDurationMs;
                        eye.pauseDurationMs = 1000L + RANDOM.nextInt(1500);
                        continue;
                    } else if (bleedElapsed >= 1070L) {
                        float closeT = (bleedElapsed - 1070L) / 180.0F;
                        openCurve = Math.max(0.0F, 1.0F - closeT * closeT);
                    } else {
                        openCurve = 1.0F;
                    }
                } else {
                    float phase = elapsed / (float) eye.activeDurationMs;
                    if (phase < 0.30F) {
                        float t = phase / 0.30F;
                        openCurve = 0.5F * (1.0F - Mth.cos(t * (float) Math.PI));
                    } else if (phase < 0.72F) {
                        float midT = (phase - 0.30F) / 0.42F;
                        openCurve = 1.0F - 0.08F * Mth.sin(midT * (float) Math.PI * 2.0F);
                    } else {
                        float t = (phase - 0.72F) / 0.28F;
                        openCurve = 0.5F * (1.0F + Mth.cos(t * (float) Math.PI));
                    }
                }

                float openness = openCurve * eye.maxOpen;
                if (openness <= 0.03F) {
                    continue;
                }
                int ex = Mth.clamp(Math.round(eye.normX * screen.width),
                        eye.halfW + 6, Math.max(eye.halfW + 8, screen.width - eye.halfW - 6));
                int ey = Mth.clamp(Math.round(eye.normY * screen.height),
                        eye.halfH + 6, Math.max(eye.halfH + 8, screen.height - eye.halfH - 6));

                if (overlapsRect(ex, ey, eye.halfW, eye.halfH, invForbid)) {
                    eye.respawn(screen, MENU_EYE_GROUPS, now);
                    ex = Mth.clamp(Math.round(eye.normX * screen.width),
                            eye.halfW + 6, Math.max(eye.halfW + 8, screen.width - eye.halfW - 6));
                    ey = Mth.clamp(Math.round(eye.normY * screen.height),
                            eye.halfH + 6, Math.max(eye.halfH + 8, screen.height - eye.halfH - 6));
                    if (overlapsRect(ex, ey, eye.halfW, eye.halfH, invForbid)) {
                        continue;
                    }
                }

                boolean thisEyeRed = menuGlitchRedEyes || (eye.bleedingRed && VoidGazeConfig.enableRedEyes);
                long bleedElapsedMs = (eye.bleedingRed && VoidGazeConfig.enableRedEyes) ? (now - eye.bleedStartMs) : 0L;
                drawSingleVerticalEye(graphics, ex, ey, eye.halfW, eye.halfH, openness,
                        openCurve * eye.maxAlpha, mouseX, mouseY, now, i * 17 + 5, thisEyeRed, bleedElapsedMs);
            }
            graphics.flush();
        } finally {
            graphics.pose().popPose();
            RenderSystem.enableDepthTest();
        }
    }

    private static void drawSingleVerticalEye(GuiGraphics graphics, int cx, int cy,
            int halfW, int halfH, float openness, float veilAlpha,
            int mouseX, int mouseY, long nowMs, int seed, boolean redEyes, long bleedElapsedMs) {
        int coreAlpha = Mth.clamp(Math.round(veilAlpha * (redEyes ? 245.0F : 210.0F)), 0, 250);
        int lidAlpha = Mth.clamp(Math.round(veilAlpha * (redEyes ? 250.0F : 165.0F)), 0, 255);
        int subtleMistAlpha = Mth.clamp(Math.round(veilAlpha * 28.0F), 0, 38);
        if (coreAlpha <= 6) {
            return;
        }

        int visHalfH = Math.max(8, Math.round(halfH * (0.48F + 0.52F * openness)));
        int curMaxRx = Math.max(3, Math.round(halfW * openness));

        float timeSec = (nowMs % 60000L) / 1000.0F;
        float glanceX = Mth.sin(timeSec * 1.8F + seed * 1.7F) * 3.0F
                + Mth.cos(timeSec * 3.1F + seed * 2.3F) * 1.3F;
        float glanceY = Mth.cos(timeSec * 1.4F + seed * 1.3F) * 5.2F
                + Mth.sin(timeSec * 2.6F + seed * 2.1F) * 2.1F;
        float toMouseX = Mth.clamp((mouseX - cx) * 0.05F, -5.5F, 5.5F);
        float toMouseY = Mth.clamp((mouseY - cy) * 0.07F, -9.0F, 9.0F);
        float lookX = Mth.clamp((toMouseX * 0.65F + glanceX * 0.55F) * openness,
                -halfW * 0.48F, halfW * 0.48F);
        float lookY = Mth.clamp((toMouseY * 0.65F + glanceY * 0.55F) * openness,
                -visHalfH * 0.46F, visHalfH * 0.46F);

        int irisCenterX = cx + Math.round(lookX);
        int irisCenterY = cy + Math.round(lookY);
        int irisRx = Math.max(5, Math.round(halfW * 0.46F));
        int irisRy = Math.max(10, Math.round(halfH * 0.38F));
        int pupilRx = Math.max(2, Math.round(halfW * 0.19F));
        int pupilRy = Math.max(7, Math.round(halfH * 0.29F));

        int subtleMistColor = (subtleMistAlpha << 24) | 0x050208;
        // When redEyes is active: pitch-black thick border + blood-crimson sclera!
        int blackSocketColor = (coreAlpha << 24) | (redEyes ? 0x000000 : 0x07040C);
        int eyelidRimColor = (lidAlpha << 24) | (redEyes ? 0x000000 : 0x0C0814);
        int scleraEdgeColor = (Mth.clamp(Math.round(veilAlpha * (redEyes ? 225.0F : 185.0F)), 0, 240) << 24)
                | (redEyes ? 0xA80818 : 0xB8B2C6);
        int scleraBrightColor = (Mth.clamp(Math.round(veilAlpha * (redEyes ? 245.0F : 215.0F)), 0, 250) << 24)
                | (redEyes ? 0xFF182C : 0xE6E2F0);
        int darkIrisOuter = (Mth.clamp(Math.round(veilAlpha * 235.0F), 0, 250) << 24)
                | (redEyes ? 0x380006 : 0x161020);
        int pupilColor = (Mth.clamp(Math.round(veilAlpha * 252.0F), 0, 255) << 24) | 0x000000;
        int glintColor = (Mth.clamp(Math.round(veilAlpha * 215.0F), 0, 245) << 24)
                | (redEyes ? 0xFF6070 : 0xF4F0FC);

        for (int dy = -visHalfH; dy <= visHalfH; dy++) {
            float ny = dy / (float) Math.max(1, visHalfH);
            float profile = Math.max(0.0F, 1.0F - ny * ny);
            int rx = Math.round(halfW * profile * openness);
            int py = cy + dy;

            if (subtleMistAlpha > 2) {
                graphics.fill(cx - rx - 2, py, cx + rx + 3, py + 1, subtleMistColor);
            }
            // Pitch-black outer outline (thicker 2px black border when redEyes is active)
            int borderPad = redEyes ? 2 : 1;
            graphics.fill(cx - rx - borderPad, py, cx + rx + borderPad + 1, py + 1, eyelidRimColor);
            if (rx <= 0) {
                continue;
            }
            graphics.fill(cx - rx, py, cx + rx + 1, py + 1, blackSocketColor);

            if (Math.abs(dy) <= visHalfH - 1 && rx >= 2) {
                graphics.fill(cx - rx + 1, py, cx + rx, py + 1, scleraEdgeColor);
                if (Math.abs(dy) <= visHalfH - 3 && rx >= 3) {
                    graphics.fill(cx - rx + 2, py, cx + rx - 1, py + 1, scleraBrightColor);
                }
            }

            float idy = (py - irisCenterY) / (float) Math.max(1, irisRy);
            if (Math.abs(idy) <= 1.0F) {
                int iSpan = Math.round(irisRx * (float) Math.sqrt(1.0F - idy * idy));
                int ix0 = Math.max(cx - rx + 1, irisCenterX - iSpan);
                int ix1 = Math.min(cx + rx, irisCenterX + iSpan + 1);
                if (ix1 > ix0) {
                    graphics.fill(ix0, py, ix1, py + 1, darkIrisOuter);
                }
            }

            float pdy = (py - irisCenterY) / (float) Math.max(1, pupilRy);
            if (Math.abs(pdy) <= 1.0F) {
                int pSpan = Math.max(1, Math.round(pupilRx * (1.0F - pdy * pdy)));
                int px0 = Math.max(cx - rx + 1, irisCenterX - pSpan);
                int px1 = Math.min(cx + rx, irisCenterX + pSpan + 1);
                if (px1 > px0) {
                    graphics.fill(px0, py, px1, py + 1, pupilColor);
                }
            }
        }

        if (openness > 0.28F) {
            int gx = Mth.clamp(irisCenterX - 1, cx - curMaxRx + 2, cx + curMaxRx - 2);
            int gy = Mth.clamp(irisCenterY - 3, cy - visHalfH + 3, cy + visHalfH - 3);
            graphics.fill(gx, gy, gx + 2, gy + 2, glintColor);
        }

        if (redEyes && bleedElapsedMs > 0L) {
            drawEyeBloodDrips(graphics, cx, cy, halfW, visHalfH, openness, bleedElapsedMs, seed);
        }
    }

    private static void drawEyeBloodDrips(GuiGraphics graphics, int cx, int cy,
            int halfW, int visHalfH, float openness, long bleedElapsedMs, int seed) {
        float prog = Mth.clamp(bleedElapsedMs / 950.0F, 0.05F, 1.0F);
        int maxSpan = Math.max(3, Math.round(halfW * openness * 0.72F));
        int[] offsets = new int[] { -maxSpan + 1, -maxSpan / 2, 0, maxSpan / 2, maxSpan - 1 };
        int[] baseLens = new int[] { 14, 24, 34, 21, 16 };
        for (int s = 0; s < offsets.length; s++) {
            int dx = offsets[s];
            float ny = 0.65F * (Math.abs(dx) / (float) Math.max(1, halfW));
            int startY = cy + Math.round(visHalfH * (0.78F - ny * 0.28F));
            int streamLen = Math.max(2, Math.round(baseLens[s] * prog
                    * (0.85F + 0.15F * Mth.sin((seed + s * 13) * 1.7F))));
            int sx = cx + dx;
            graphics.fill(sx - 1, startY, sx + 2, startY + streamLen + 1, 0xCC000000);
            graphics.fill(sx, startY, sx + 1, startY + streamLen, 0xEEB80014);
            if (streamLen > 4) {
                graphics.fill(sx, startY + 1, sx + 1, startY + streamLen / 2, 0xFFFF182C);
            }
            int dropOffset = Math.round(((bleedElapsedMs + s * 140L) % 520L) / 520.0F * 14.0F);
            int dropY = startY + streamLen + 2 + dropOffset;
            graphics.fill(sx - 1, dropY - 1, sx + 2, dropY + 3, 0xCC000000);
            graphics.fill(sx, dropY, sx + 1, dropY + 2, 0xFFE6081C);
        }
    }

    private static final class MenuEyeGroup {
        float normX;
        float normY;
        int halfW;
        int halfH;
        long cycleStartMs;
        long activeDurationMs;
        long pauseDurationMs;
        float maxAlpha;
        float maxOpen;
        boolean snappingClosed;
        long snapStartMs;
        boolean bleedingRed;
        long bleedStartMs;

        void respawn(Screen screen, List<MenuEyeGroup> existing, long nowMs) {
            this.cycleStartMs = nowMs;
            this.activeDurationMs = 3600L + RANDOM.nextInt(2400);
            this.pauseDurationMs = 600L + RANDOM.nextInt(1400);
            this.snappingClosed = false;
            this.snapStartMs = 0L;
            this.bleedingRed = false;
            this.bleedStartMs = 0L;
            this.maxAlpha = 0.68F + RANDOM.nextFloat() * 0.20F;
            this.halfW = 15 + RANDOM.nextInt(6);
            this.halfH = 30 + RANDOM.nextInt(10);
            this.maxOpen = 0.66F + RANDOM.nextFloat() * 0.20F;

            float bestX = 0.08F + RANDOM.nextFloat() * 0.84F;
            float bestY = 0.10F + RANDOM.nextFloat() * 0.80F;
            int sw = Math.max(120, screen.width);
            int sh = Math.max(120, screen.height);
            int[] invForbid = getInventoryForbiddenRect(screen);

            for (int attempt = 0; attempt < 36; attempt++) {
                float candX;
                float candY = 0.10F + RANDOM.nextFloat() * 0.80F;
                if (invForbid != null) {
                    int leftMaxPx = invForbid[0] - this.halfW - 6;
                    int rightMinPx = invForbid[2] + this.halfW + 6;
                    int leftSpan = Math.max(0, leftMaxPx - (this.halfW + 8));
                    int rightSpan = Math.max(0, (sw - this.halfW - 8) - rightMinPx);
                    if (leftSpan > 4 && (rightSpan <= 4 || RANDOM.nextBoolean())) {
                        int pxChoice = (this.halfW + 8) + RANDOM.nextInt(leftSpan);
                        candX = pxChoice / (float) sw;
                    } else if (rightSpan > 4) {
                        int pxChoice = rightMinPx + RANDOM.nextInt(rightSpan);
                        candX = pxChoice / (float) sw;
                    } else {
                        candX = 0.05F + RANDOM.nextFloat() * 0.90F;
                    }
                } else {
                    candX = 0.07F + RANDOM.nextFloat() * 0.86F;
                }

                int px = Math.round(candX * sw);
                int py = Math.round(candY * sh);
                boolean conflict = overlapsRect(px, py, this.halfW, this.halfH, invForbid);

                if (!conflict) {
                    for (GuiEventListener listener : screen.children()) {
                        if (listener instanceof AbstractWidget widget && widget.visible) {
                            if (px + this.halfW >= widget.getX() - 8
                                    && px - this.halfW <= widget.getX() + widget.getWidth() + 8
                                    && py + this.halfH >= widget.getY() - 8
                                    && py - this.halfH <= widget.getY() + widget.getHeight() + 8) {
                                conflict = true;
                                break;
                            }
                        }
                    }
                }
                if (!conflict && existing != null) {
                    for (MenuEyeGroup other : existing) {
                        if (other == this) {
                            continue;
                        }
                        float dx = (candX - other.normX) * sw;
                        float dy = (candY - other.normY) * sh;
                        if (dx * dx + dy * dy < 68.0F * 68.0F) {
                            conflict = true;
                            break;
                        }
                    }
                }
                if (!conflict) {
                    bestX = candX;
                    bestY = candY;
                    break;
                } else if (attempt == 0) {
                    bestX = candX;
                    bestY = candY;
                }
            }
            this.normX = bestX;
            this.normY = bestY;
        }
    }
}
