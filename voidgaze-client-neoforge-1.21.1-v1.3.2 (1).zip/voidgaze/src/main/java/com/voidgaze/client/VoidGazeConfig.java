package com.voidgaze.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

/**
 * Persistent client-side configuration for VoidGaze.
 * Saved to {@code config/voidgaze-client.properties}.
 */
public final class VoidGazeConfig {
    // HUD / Gameplay distortion timing settings (in seconds)
    public static int minIntervalSec = 20;
    public static int maxIntervalSec = 45;
    public static int minDurationSec = 7;
    public static int maxDurationSec = 14;

    // Separate Inventory / Menu distortion timing settings (in seconds)
    public static int invMinIntervalSec = 25;
    public static int invMaxIntervalSec = 60;
    public static int invMinDurationSec = 5;
    public static int invMaxDurationSec = 10;

    // Individual feature toggles
    public static boolean enableHearts = true;
    public static boolean enableXp = true;
    public static boolean enableArmor = true;
    public static boolean enableFood = true;
    public static boolean enableInversion = true;
    public static boolean enableUiMovement = true;
    public static boolean enableItemGlitch = true;
    public static boolean enableEyes = true;
    public static boolean enableRedEyes = true;
    public static boolean enableMainMenuGlitch = true;
    public static boolean enableScreenDistortion = true;
    public static boolean enableWornArmorGlitch = true;
    public static boolean enableGameplayItemGlitch = true;

    private static boolean loaded = false;

    private VoidGazeConfig() {}

    public static void ensureLoaded() {
        if (!loaded) {
            load();
        }
    }

    public static void resetDefaults() {
        minIntervalSec = 20;
        maxIntervalSec = 45;
        minDurationSec = 7;
        maxDurationSec = 14;
        invMinIntervalSec = 25;
        invMaxIntervalSec = 60;
        invMinDurationSec = 5;
        invMaxDurationSec = 10;
        enableHearts = true;
        enableXp = true;
        enableArmor = true;
        enableFood = true;
        enableInversion = true;
        enableUiMovement = true;
        enableItemGlitch = true;
        enableEyes = true;
        enableRedEyes = true;
        enableMainMenuGlitch = true;
        enableScreenDistortion = true;
        enableWornArmorGlitch = true;
        enableGameplayItemGlitch = true;
        save();
    }

    private static File getConfigFile() {
        Minecraft mc = Minecraft.getInstance();
        File gameDir = (mc != null && mc.gameDirectory != null) ? mc.gameDirectory : new File(".");
        File configDir = new File(gameDir, "config");
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
        return new File(configDir, "voidgaze-client.properties");
    }

    public static void load() {
        loaded = true;
        File file = getConfigFile();
        if (!file.exists()) {
            save();
            return;
        }
        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream(file)) {
            props.load(in);
            minIntervalSec = Mth.clamp(parseInt(props.getProperty("minIntervalSec"), 20), 1, 300);
            maxIntervalSec = Mth.clamp(parseInt(props.getProperty("maxIntervalSec"), 45), 1, 300);
            if (maxIntervalSec < minIntervalSec) {
                maxIntervalSec = minIntervalSec;
            }
            minDurationSec = Mth.clamp(parseInt(props.getProperty("minDurationSec"), 7), 1, 120);
            maxDurationSec = Mth.clamp(parseInt(props.getProperty("maxDurationSec"), 14), 1, 120);
            if (maxDurationSec < minDurationSec) {
                maxDurationSec = minDurationSec;
            }

            invMinIntervalSec = Mth.clamp(parseInt(props.getProperty("invMinIntervalSec"), 25), 1, 300);
            invMaxIntervalSec = Mth.clamp(parseInt(props.getProperty("invMaxIntervalSec"), 60), 1, 300);
            if (invMaxIntervalSec < invMinIntervalSec) {
                invMaxIntervalSec = invMinIntervalSec;
            }
            invMinDurationSec = Mth.clamp(parseInt(props.getProperty("invMinDurationSec"), 5), 1, 120);
            invMaxDurationSec = Mth.clamp(parseInt(props.getProperty("invMaxDurationSec"), 10), 1, 120);
            if (invMaxDurationSec < invMinDurationSec) {
                invMaxDurationSec = invMinDurationSec;
            }

            enableHearts = parseBoolean(props.getProperty("enableHearts"), true);
            enableXp = parseBoolean(props.getProperty("enableXp"), true);
            enableArmor = parseBoolean(props.getProperty("enableArmor"), true);
            enableFood = parseBoolean(props.getProperty("enableFood"), true);
            enableInversion = parseBoolean(props.getProperty("enableInversion"), true);
            enableUiMovement = parseBoolean(props.getProperty("enableUiMovement"), true);
            enableItemGlitch = parseBoolean(props.getProperty("enableItemGlitch"), true);
            enableEyes = parseBoolean(props.getProperty("enableEyes"), true);
            enableRedEyes = parseBoolean(props.getProperty("enableRedEyes"), true);
            enableMainMenuGlitch = parseBoolean(props.getProperty("enableMainMenuGlitch"), true);
            enableScreenDistortion = parseBoolean(props.getProperty("enableScreenDistortion"), true);
            enableWornArmorGlitch = parseBoolean(props.getProperty("enableWornArmorGlitch"), true);
            enableGameplayItemGlitch = parseBoolean(props.getProperty("enableGameplayItemGlitch"), true);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("minIntervalSec", Integer.toString(minIntervalSec));
        props.setProperty("maxIntervalSec", Integer.toString(maxIntervalSec));
        props.setProperty("minDurationSec", Integer.toString(minDurationSec));
        props.setProperty("maxDurationSec", Integer.toString(maxDurationSec));
        props.setProperty("invMinIntervalSec", Integer.toString(invMinIntervalSec));
        props.setProperty("invMaxIntervalSec", Integer.toString(invMaxIntervalSec));
        props.setProperty("invMinDurationSec", Integer.toString(invMinDurationSec));
        props.setProperty("invMaxDurationSec", Integer.toString(invMaxDurationSec));
        props.setProperty("enableHearts", Boolean.toString(enableHearts));
        props.setProperty("enableXp", Boolean.toString(enableXp));
        props.setProperty("enableArmor", Boolean.toString(enableArmor));
        props.setProperty("enableFood", Boolean.toString(enableFood));
        props.setProperty("enableInversion", Boolean.toString(enableInversion));
        props.setProperty("enableUiMovement", Boolean.toString(enableUiMovement));
        props.setProperty("enableItemGlitch", Boolean.toString(enableItemGlitch));
        props.setProperty("enableEyes", Boolean.toString(enableEyes));
        props.setProperty("enableRedEyes", Boolean.toString(enableRedEyes));
        props.setProperty("enableMainMenuGlitch", Boolean.toString(enableMainMenuGlitch));
        props.setProperty("enableScreenDistortion", Boolean.toString(enableScreenDistortion));
        props.setProperty("enableWornArmorGlitch", Boolean.toString(enableWornArmorGlitch));
        props.setProperty("enableGameplayItemGlitch", Boolean.toString(enableGameplayItemGlitch));

        File file = getConfigFile();
        try (FileOutputStream out = new FileOutputStream(file)) {
            props.store(out, "VoidGaze Client Mod Configuration");
        } catch (Exception ignored) {
        }
    }

    private static int parseInt(String val, int fallback) {
        if (val == null) {
            return fallback;
        }
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static boolean parseBoolean(String val, boolean fallback) {
        if (val == null) {
            return fallback;
        }
        return Boolean.parseBoolean(val.trim());
    }
}
