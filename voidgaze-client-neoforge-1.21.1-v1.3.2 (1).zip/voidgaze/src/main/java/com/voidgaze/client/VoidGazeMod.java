package com.voidgaze.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;

/**
 * Standalone client-only mod ("VoidGaze") for Minecraft 1.21.1 (NeoForge).
 * Safe to use on any vanilla or modded multiplayer server.
 */
@Mod(value = VoidGazeMod.MODID, dist = Dist.CLIENT)
public final class VoidGazeMod {
    public static final String MODID = "voidgaze";

    public VoidGazeMod() {
        // Pure client-side mod; all rendering and tick hooks are registered via @EventBusSubscriber.
    }
}
